﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text.RegularExpressions;
namespace SearchKeyword
{
    class Program
    {
        static void Main(string[] args)
        {
            StartProgram();
        }
        public static void StartProgram() {

            // Create folder directory if not exist
            string path = @"C:\SearchKeyword";
            bool exists = System.IO.Directory.Exists(path);
            System.IO.Directory.CreateDirectory(path); //If the folder does not exist yet, it will be created. If the folder exists already, the line will be ignored.

            Console.WriteLine("1. Enter filename <filename.extension> to search ");
            Console.WriteLine("2. To exit program at anytime,write letsquit");
            string inputParam = Console.ReadLine();
            string trimmedInputParam = inputParam.Trim().ToLower();
            if (trimmedInputParam == "letsquit")
            {
                EndProgram();
            }
            else if (trimmedInputParam != String.Empty)
            {
                if (trimmedInputParam.Contains("."))
                {
                    // GET FILE EXTENSION FROM INPUT PARAM AND LOOK FOR TEXT FILE ONLY
                    string fileExt = trimmedInputParam.Split('.')[1];
                    if (fileExt.Trim().ToLower() == "txt")
                    {
                        SearchFileInDirectory(trimmedInputParam);
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("***** The specified file extension is not supported *****");
                        Console.WriteLine();
                        StartProgram();
                    }
                }
                else {
                    // if no file exists
                    Console.WriteLine();
                    Console.WriteLine("***** File " + "'" + trimmedInputParam + "'" + " does not exist *****");
                    Console.WriteLine();
                    StartProgram();
                }
                
            }
        }
        public static void EndProgram() {
            Environment.Exit(0);
        }
        public static void SearchFileInDirectory(string filename) {

            // SEARCH FOR FILE IN THE DIRECTORY
            string path = @"C:\SearchKeyword";
            DirectoryInfo di = new DirectoryInfo(path);
            // For an exact match
            foreach (var fi in di.GetFiles(filename))
            {
                Console.WriteLine();
                ReadFile(fi.FullName);
            }
           
        }

        public static void ReadFile(string pathToFile) {
            List<string> searchResult = null;
            Console.Write("Input searchterm: ");
            string inputParam = Console.ReadLine();
            if (inputParam.ToLower().Trim() == "letsquit") {
                EndProgram();
            }
            foreach (var line in File.ReadAllLines(pathToFile))
            {
                if (line.Trim().ToLower().Contains(inputParam.Trim().ToLower()))
                {
                    if (searchResult == null) {
                        searchResult = new List<string>();
                    }                                    
                    int wordFrequency = 3;
                    var words = line.Split(' ').ToArray(); // split into words by space
                    int foundndex = Array.FindIndex(words, w => w.Equals(inputParam));
                                                                                 
                    var wordsArray = Enumerable
                            .Range((foundndex - wordFrequency) > 0 ? (foundndex - wordFrequency) : 0, (wordFrequency * 2 + 1 > (words.Length) - 1) ? (words.Length) - 1 : wordFrequency * 2 + 1)
                            .Select(i => words[i]).ToArray();

                    var outPut = string.Join(" ", wordsArray);
                    searchResult.Add(outPut);
                }
            }
            if (searchResult != null)
            {
                string s = String.Join("\n", searchResult); // show final search result lines delimited by newline
                Console.WriteLine(s);
            }
            else {
                Console.WriteLine("***** Keyword " + "'" + inputParam + "'" + " not found *****");
            }
            searchResult = null; // emtpy the list      
            Console.WriteLine();
            ReadFile(pathToFile); // recursively call method to search another keyword
        }
    }
}
